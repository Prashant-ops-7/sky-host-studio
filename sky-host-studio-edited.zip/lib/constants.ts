export const CLIENT_PORTAL_URL = "https://client.lapatahost.com/"
