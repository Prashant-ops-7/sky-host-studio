import SHSPricing from "./components/SHSPricing";

export default function Home() {
  return <SHSPricing />;
}
