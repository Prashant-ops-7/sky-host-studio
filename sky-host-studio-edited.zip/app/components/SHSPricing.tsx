"use client";

import { useState } from "react";
import { Cpu, HardDrive, MemoryStick, Server, Bot, Zap, ShieldCheck, ChevronRight } from "lucide-react";

const DISCORD_INVITE = "https://discord.gg/Xy7WFDj5EP";
const categories = [
  {
    id: "basic", eyebrow: "INTEL CPU", title: "Minecraft Basic", subtitle: "Reliable, budget-friendly power for your Minecraft world.", icon: Server,
    plans: [
      { name: "WOOD PLAN", price: 30, ram: "2 GB", cpu: "150%", ssd: "20 GB" },
      { name: "STONE PLAN", price: 60, ram: "4 GB", cpu: "200%", ssd: "25 GB" },
      { name: "COPPER PLAN", price: 90, ram: "8 GB", cpu: "250%", ssd: "30 GB" },
      { name: "IRON PLAN", price: 120, ram: "16 GB", cpu: "350%", ssd: "35 GB" },
    ],
  },
  {
    id: "performance", eyebrow: "AMD CPU", title: "Minecraft Performance", subtitle: "Extra processing power for demanding gameplay and bigger communities.", icon: Zap,
    plans: [
      { name: "GOLD PLAN", price: 50, ram: "2 GB", cpu: "200%", ssd: "10 GB" },
      { name: "DIAMOND PLAN", price: 100, ram: "4 GB", cpu: "300%", ssd: "20 GB" },
      { name: "NETHERITE PLAN", price: 200, ram: "8 GB", cpu: "400%", ssd: "30 GB" },
      { name: "BEDROCK PLAN", price: 400, ram: "16 GB", cpu: "600%", ssd: "40 GB" },
    ],
  },
  {
    id: "bot", eyebrow: "LIGHTWEIGHT & FLEXIBLE", title: "Bot Hosting", subtitle: "Keep your Discord bots and small applications online.", icon: Bot,
    plans: [
      { name: "BASIC", price: 10, ram: "250 MB", cpu: "50%", ssd: "2 GB" },
      { name: "STARTER", price: 25, ram: "500 MB", cpu: "75%", ssd: "3 GB" },
      { name: "PRO", price: 50, ram: "1.5 GB", cpu: "100%", ssd: "5 GB" },
      { name: "ADVANCE", price: 75, ram: "2 GB", cpu: "150%", ssd: "10 GB" },
      { name: "ULTIMATE", price: 100, ram: "4 GB", cpu: "250%", ssd: "20 GB" },
    ],
  },
];

export default function SHSPricing() {
  const [active, setActive] = useState("basic");
  return (
    <main className="min-h-screen overflow-hidden bg-[#07050d] text-white selection:bg-purple-500/40">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(124,58,237,0.20),transparent_48%)]" />
      <header className="relative z-10 border-b border-white/10 bg-black/20 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
          <a href="#home" className="flex items-center gap-3" aria-label="SKY HOST & STUDIO home">
            <span className="grid h-11 w-11 place-items-center rounded-xl border border-purple-300/30 bg-gradient-to-br from-violet-500 to-purple-900 font-black tracking-tight shadow-lg shadow-purple-900/30">SHS</span>
            <span className="leading-tight"><span className="block text-sm font-extrabold tracking-[0.12em]">SKY HOST</span><span className="text-xs font-semibold tracking-[0.28em] text-purple-300">& STUDIO</span></span>
          </a>
          <a href={DISCORD_INVITE} target="_blank" rel="noreferrer" className="rounded-xl border border-purple-400/40 bg-purple-600/15 px-4 py-2.5 text-sm font-bold text-purple-100 transition hover:bg-purple-600/30">Join Discord <ChevronRight className="ml-1 inline h-4 w-4" /></a>
        </div>
      </header>

      <section id="home" className="relative z-10 mx-auto max-w-7xl px-5 pb-14 pt-20 text-center sm:px-8 sm:pb-20 sm:pt-28">
        <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-purple-400/25 bg-purple-500/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.2em] text-purple-200"><span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_#34d399]" /> Hosting made for your next level</div>
        <h1 className="mx-auto max-w-4xl text-4xl font-black leading-tight tracking-tight sm:text-6xl lg:text-7xl">Your world. Your server.<br/><span className="bg-gradient-to-r from-violet-300 via-purple-400 to-fuchsia-300 bg-clip-text text-transparent">Your SKY.</span></h1>
        <p className="mx-auto mt-6 max-w-2xl text-base leading-7 text-slate-400 sm:text-lg">Minecraft and bot hosting with clear monthly pricing, straightforward specs, and plans for every stage of your journey.</p>
        <a href="#plans" className="mt-8 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 px-6 py-3.5 font-bold shadow-xl shadow-purple-950/50 transition hover:-translate-y-0.5 hover:from-violet-500 hover:to-purple-500">Explore Plans <ChevronRight className="h-5 w-5" /></a>
        <div className="mx-auto mt-12 grid max-w-2xl grid-cols-3 gap-3 text-left">
          {[{big:"13",small:"Hosting plans"},{big:"3",small:"Plan categories"},{big:"₹10+",small:"Starting monthly"}].map((item)=><div key={item.small} className="rounded-2xl border border-white/10 bg-white/[0.035] p-4 sm:p-5"><div className="text-2xl font-black text-white sm:text-3xl">{item.big}</div><div className="mt-1 text-xs text-slate-400 sm:text-sm">{item.small}</div></div>)}
        </div>
      </section>

      <section id="plans" className="relative z-10 mx-auto max-w-7xl px-5 pb-24 sm:px-8">
        <div className="mb-8 text-center"><p className="text-xs font-bold uppercase tracking-[0.3em] text-purple-300">Choose your power</p><h2 className="mt-3 text-3xl font-black sm:text-4xl">Hosting <span className="text-purple-300">Plans</span></h2><p className="mt-3 text-sm text-slate-400">All prices are in Indian Rupees (₹) and billed monthly.</p></div>
        <div className="mx-auto mb-10 flex max-w-3xl flex-wrap justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-2">
          {categories.map((cat)=>{const Icon=cat.icon; return <button key={cat.id} onClick={()=>setActive(cat.id)} className={`flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition ${active===cat.id?"bg-purple-600 text-white shadow-lg shadow-purple-950/40":"text-slate-400 hover:bg-white/5 hover:text-white"}`}><Icon className="h-4 w-4" />{cat.title}</button>})}
        </div>
        {categories.map((cat)=>{const Icon=cat.icon; return <div key={cat.id} className={active===cat.id?"block":"hidden"}>
          <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="mb-2 inline-flex items-center gap-2 text-xs font-bold tracking-[0.22em] text-purple-300"><Icon className="h-4 w-4" /> {cat.eyebrow}</div><h3 className="text-2xl font-black sm:text-3xl">{cat.title}</h3><p className="mt-2 text-sm text-slate-400">{cat.subtitle}</p></div><span className="w-fit rounded-full border border-white/10 px-3 py-1.5 text-xs text-slate-300">{cat.plans.length} plans · ₹ / month</span></div>
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">{cat.plans.map((plan,index)=><article key={plan.name} className="group relative flex flex-col overflow-hidden rounded-2xl border border-purple-300/15 bg-gradient-to-b from-[#171024] to-[#0c0914] p-5 transition duration-300 hover:-translate-y-1 hover:border-purple-400/50 hover:shadow-2xl hover:shadow-purple-950/30"><div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-purple-400/80 to-transparent"/><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] font-bold tracking-[0.22em] text-purple-300">{cat.id==="bot"?"BOT SERVER":cat.id==="basic"?"INTEL EDITION":"AMD EDITION"}</p><h4 className="mt-2 text-lg font-extrabold tracking-wide">{plan.name}</h4></div><span className="grid h-9 w-9 place-items-center rounded-xl border border-purple-400/20 bg-purple-500/10 text-sm font-black text-purple-200">{String(index+1).padStart(2,"0")}</span></div><div className="mt-5 flex items-baseline gap-1"><span className="text-4xl font-black tracking-tight">₹{plan.price}</span><span className="text-sm text-slate-400">/ month</span></div><div className="my-5 h-px bg-white/10"/><div className="space-y-4 text-sm"><div className="flex items-center justify-between"><span className="flex items-center gap-2 text-slate-400"><MemoryStick className="h-4 w-4 text-purple-300"/> RAM</span><strong>{plan.ram}</strong></div><div className="flex items-center justify-between"><span className="flex items-center gap-2 text-slate-400"><Cpu className="h-4 w-4 text-purple-300"/> CPU</span><strong>{plan.cpu}</strong></div><div className="flex items-center justify-between"><span className="flex items-center gap-2 text-slate-400"><HardDrive className="h-4 w-4 text-purple-300"/> SSD Storage</span><strong>{plan.ssd}</strong></div></div><a href={DISCORD_INVITE} target="_blank" rel="noreferrer" className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl border border-purple-400/40 bg-purple-600/15 px-4 py-3 text-sm font-bold text-purple-100 transition hover:border-purple-300 hover:bg-purple-600 hover:text-white">Order Now <ChevronRight className="h-4 w-4"/></a></article>)}</div>
        </div>})}
      </section>
      <section className="relative z-10 border-y border-white/10 bg-white/[0.025] px-5 py-12 text-center"><ShieldCheck className="mx-auto h-8 w-8 text-purple-300"/><h2 className="mt-4 text-xl font-extrabold">Need help choosing a plan?</h2><p className="mt-2 text-sm text-slate-400">Join our Discord and talk to the SKY HOST & STUDIO team.</p><a href={DISCORD_INVITE} target="_blank" rel="noreferrer" className="mt-5 inline-flex rounded-xl bg-white px-5 py-3 text-sm font-extrabold text-black transition hover:bg-purple-100">Contact the team</a></section>
      <footer className="relative z-10 px-5 py-7 text-center text-xs text-slate-500">© {new Date().getFullYear()} SKY HOST & STUDIO. All rights reserved. <span className="mx-2 text-purple-400">•</span> Built for your next adventure.</footer>
    </main>
  );
}
